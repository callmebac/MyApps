package csu.example.myknn;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;


import java.util.ArrayList;
import android.R.integer;
import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.content.ContentUris;
import android.database.Cursor;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class MyKnnActivity extends Activity implements SensorEventListener{

    private SensorManager sensorManager;
    private Sensor sensor;

    private ArrayList<MyKnnNode> KnnPoints = new ArrayList<MyKnnNode>();
    private float AccelX = 0;
    private float AccelY = 0;
    private float AccelZ = 0;
    private int n = 0;
    private Button button1;
    private TextView textView1;
    private MyKnnCluster knnclusters [] = new MyKnnCluster[3];
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_knn);

        //1、得到sensorManager对象
        sensorManager = (SensorManager)this.getSystemService(SENSOR_SERVICE);
        //2、得到sensor
        sensor = sensorManager.getDefaultSensor(SensorManager.SENSOR_ACCELEROMETER);
        //3、得到感应事件监听，通过注册实现
        textView1 = (TextView) findViewById(R.id.textView1);
        button1 = (Button) findViewById(R.id.button1);
        button1.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                textView1.setText("稍等……");

                //取各个点装入分类器中


                //跑步的点
                ArrayList<MyKnnNode> knnRunNodes = new ArrayList<MyKnnNode>();
                Uri uriRun=Uri.parse("content://com.example.sharedata.myProvider/run");
                Cursor cursorRun = MyKnnActivity.this.getContentResolver().query(
                        uriRun, null, null, null, null);
                if ((cursorRun != null) && cursorRun.getCount() > 0) {
                    while (cursorRun.moveToNext()) {
                        String idString = cursorRun.getString(0);
                        Log.i("cursorRun", idString);
                        int ind = Integer.parseInt(idString);
                        String AccelX =  cursorRun.getString(1);
                        String AccelY =  cursorRun.getString(2);
                        String AccelZ =  cursorRun.getString(3);
                        Log.i("cursorRun", AccelX );
                        Log.i("cursorRun", AccelY );
                        Log.i("cursorRun", AccelZ );
                        double accX = Double.parseDouble(AccelX);
                        double accY = Double.parseDouble(AccelY);
                        double accZ = Double.parseDouble(AccelZ);
                        double dimension[] ={accX ,accY ,accZ };
                        MyKnnNode KnnPoint = new MyKnnNode(ind, dimension);
                        knnRunNodes.add(KnnPoint);
                    }
                }
                knnclusters[0] = new MyKnnCluster("run", knnRunNodes);






                //走路的点

                ArrayList<MyKnnNode> knnWalkNodes = new ArrayList<MyKnnNode>();
                Uri uriWalk=Uri.parse("content://com.example.sharedata.myProvider/walk");
                Cursor cursorWalk = MyKnnActivity.this.getContentResolver().query(
                        uriWalk, null, null, null, null);
                if ((cursorWalk != null) && cursorWalk.getCount() > 0) {
                    while (cursorWalk.moveToNext()) {
                        String idString = cursorWalk.getString(0);
                        Log.i("cursorWalk", idString);
                        int ind = Integer.parseInt(idString);
                        String AccelX = cursorWalk.getString(1);
                        String AccelY = cursorWalk.getString(2);
                        String AccelZ = cursorWalk.getString(3);
                        Log.i("cursorWalk", AccelX );
                        Log.i("cursorWalk", AccelY );
                        Log.i("cursorWalk", AccelZ );
                        double accX = Double.parseDouble(AccelX);
                        double accY = Double.parseDouble(AccelY);
                        double accZ = Double.parseDouble(AccelZ);
                        double dimension[] ={accX ,accY ,accZ };
                        MyKnnNode KnnPoint = new MyKnnNode(ind, dimension);
                        knnWalkNodes.add(KnnPoint);
                    }
                }
                knnclusters[1] = new MyKnnCluster("walk", knnWalkNodes);




                //坐的点

                ArrayList<MyKnnNode> knnSitNodes = new ArrayList<MyKnnNode>();
                Uri uriSit=Uri.parse("content://com.example.sharedata.myProvider/sit");
                Cursor cursorSit = MyKnnActivity.this.getContentResolver().query(
                        uriSit, null, null, null, null);
                if ((cursorSit != null) && cursorSit.getCount() > 0) {
                    while (cursorSit.moveToNext()) {
                        String idString = cursorSit.getString(0);
                        Log.i("cursorSit", idString);
                        int ind = Integer.parseInt(idString);
                        String AccelX = cursorSit.getString(1);
                        String AccelY = cursorSit.getString(2);
                        String AccelZ = cursorSit.getString(3);
                        Log.i("cursorSit", AccelX );
                        Log.i("cursorSit", AccelY );
                        Log.i("cursorSit", AccelZ );
                        double accX = Double.parseDouble(AccelX);
                        double accY = Double.parseDouble(AccelY);
                        double accZ = Double.parseDouble(AccelZ);
                        double dimension[] ={accX ,accY ,accZ };
                        MyKnnNode KnnPoint = new MyKnnNode(ind, dimension);
                        knnSitNodes.add(KnnPoint);
                    }
                }
                knnclusters[2] = new MyKnnCluster("sit", knnSitNodes);


                Log.i("i", knnclusters[0].getClusterName());
                Log.i("i", knnclusters[1].getClusterName());
                Log.i("i", knnclusters[2].getClusterName());

            }
        });



    }

    @Override
    protected void onPause() {
        // TODO Auto-generated method stub
        super.onPause();
    }

    @Override
    protected void onResume() {
        // TODO Auto-generated method stub
        super.onResume();
        sensorManager.registerListener(this, sensor,sensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_my_knn, menu);
        return true;
    }

    @Override
    public void onAccuracyChanged(Sensor arg0, int arg1) {
        // TODO Auto-generated method stub

    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        // TODO Auto-generated method stub
        if(textView1.getText().equals("稍等……")&&(KnnPoints.size() < 200) ){
            AccelX= event.values[0] ;
            AccelY= event.values[1] ;
            AccelZ= event.values[2] ;
            Log.i("MD---x"+n, " " + AccelX);
            Log.i("MD---y"+n, " " + AccelY);
            Log.i("MD---z"+n, " " + AccelZ);
            n++;
            double dimension [] = {AccelX,AccelY,AccelZ};
            MyKnnNode knNnode = new MyKnnNode(n,dimension);
            KnnPoints.add(knNnode);
        }else if(!(KnnPoints.size() < 200)) {
            sensorManager.unregisterListener(this);
            textView1.setText("在分析您的活动方式！");
            if(textView1.getText().equals("在分析您的活动方式！")){
                MyKnnClassify knnClassify = new MyKnnClassify(knnclusters,KnnPoints);
                knnClassify.calEuclideanDistanceSum();
                int  runs = 0 ,sits = 0 ,walks = 0;
                for (int j = 0; j < KnnPoints.size(); j++) {
                    Log.i(" 距离是："," " + KnnPoints.get(j).getInstance());
                    Log.i(" 类别是："," " + KnnPoints.get(j).getClassification());
                    if( (KnnPoints.get(j).getClassification()).equals("run")){
                        runs ++;
                    }else if((KnnPoints.get(j).getClassification()).equals("walk")){
                        walks++;
                    }else {
                        sits++;
                    }
                }

                Log.i("runs", " " + runs);
                Log.i("walks", " " + walks);
                Log.i("sits", " " + sits);
                if(runs <= walks && sits <= walks){
                    textView1.setText("您在走路！");
                }
                else if(walks <= runs && sits <= runs){
                    textView1.setText("您在跑步！");
                }
                else if(walks <= sits && runs <= sits){
                    textView1.setText("您坐着！");
                }else{
                    textView1.setText("无法判断您的运动方式！");
                }
            }
        }

    }


}
